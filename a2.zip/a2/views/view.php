<!DOCTYPE html>
  <html>
    <head>
      <title>Andrew's first View</title>
    </head>
    <body>
      <h1>Hello From My View!</h1>
      <ul>
        <li>
          User ID: <?php echo $userid ?>
        </li>
        <li>
          First Name: <?php echo $firstname ?>
        </li>
        <li>
          Last Name: <?php echo $lastname ?>
        </li>
        <li>
          Email: <?php echo $email ?>
        </li>
        <li>
          Role: <?php echo $role ?>
        </li>
      </ul>

    </body>
  </html>
