<?php

define('ABSOLUTE_PATH', '/home/ajroembk/htdocs/CIT31300/a1');
define('URL_ROOT', 'http://corsair.cs.iupui.edu:23701/CIT31300/a1');
//bug - there was no closing php tag for the web config
?>
